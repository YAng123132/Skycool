# Personal Website - Yahia Refaiea [Beta]

A Pen created on CodePen.io. Original URL: [https://codepen.io/yahiarefaiea/pen/xyNWQq](https://codepen.io/yahiarefaiea/pen/xyNWQq).

A 21 years old interaction designer who grows up in a small town in Syria.